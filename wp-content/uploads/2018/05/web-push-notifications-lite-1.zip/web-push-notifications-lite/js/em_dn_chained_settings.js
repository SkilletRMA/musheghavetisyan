jQuery(document).ready(function($) {
    $("#ac_var_type").chained("#ac_var");
    $("#ac_hook").chained("#ac_var");
    $("#ac_target").chained("#ac_hook");
    $("#ac_user_con_role").chained("#ac_user_con");
});