jQuery(document).ready(function($) {
	$(document).on('click', '.maxbusiness_go_to_section', function (event) {
		event.preventDefault();
		var id = jQuery(this).attr('href');
		if( typeof(id) != 'undefined' ) {
			jQuery(id).find('h3').trigger('click');
		}
	});

	//FontAwesome Icon Control JS
    $('body').on('click', '.maxbusiness-icon-list li', function(){
        var icon_class = $(this).find('i').attr('class');
        $(this).addClass('icon-active').siblings().removeClass('icon-active');
        $(this).parent('.maxbusiness-icon-list').prev('.maxbusiness-selected-icon').children('i').attr('class','').addClass(icon_class);
        $(this).parent('.maxbusiness-icon-list').next('input').val(icon_class).trigger('change');
    });

    $(document).on('click', '.maxbusiness-selected-icon', function(){
        $(this).next().slideToggle();
    });
    
});