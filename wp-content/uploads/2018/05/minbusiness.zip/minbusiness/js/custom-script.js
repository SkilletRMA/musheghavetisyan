jQuery(document).ready(function($) {
		jQuery('.nav li.dropdown, .nav li.dropdown-menu').hover(function() {
			if (jQuery(window).width() > 767) {
				jQuery(this).addClass('open');
			}
		}, function() { 
			if (jQuery(window).width() > 767) {
			jQuery(this).removeClass('open');
			}
		});
		

	jQuery('.nav li.dropdown').find('.mobile-eve').each(function() {
		jQuery(this).on('click', function() {
			if (jQuery(window).width() < 768) {
				jQuery(this).parent().next().slideToggle();
			}
			return false;
		});
	});
	
	var swiper = new Swiper('.home-slider', {
		pagination: '.slider-page',
		nextButton: '.slider-next',
		prevButton: '.slider-prev',
		paginationClickable:true,
		spaceBetween:30,
		autoplay:5000,
		
	});
	var swiper = new Swiper('.swiper-blog', {
		nextButton: '.blog-next',
		prevButton: '.blog-prev',
		slidesPerView: '3',
        autoplay:5000,
        breakpoints: {
            1024: {
                slidesPerView: 3,
                spaceBetween: 10
            },
            768: {
                slidesPerView: 2,
                spaceBetween: 10
            },
            640: {
                slidesPerView: 2,
                spaceBetween: 10
            },
            480: {
                slidesPerView: 1,
                spaceBetween: 10
            }
        }
		
	});

	var swiper = new Swiper('.swiper-client', {
		// pagination: '.client-page',
		nextButton: '.client-next',
		prevButton: '.client-prev',
		slidesPerView: '4',
        spaceBetween:10,
		autoplay:5000,
		breakpoints: {
            1024: {
                slidesPerView: 3,
                spaceBetween: 10
            },
            768: {
                slidesPerView: 3,
                spaceBetween: 10
            },
            640: {
                slidesPerView: 2,
                spaceBetween: 10
            },
            480: {
                slidesPerView: 2,
                spaceBetween: 10
            }
        }
		
	});

	var gallery = $('.blog-gallery .tft-blog-img').simpleLightbox();
});
