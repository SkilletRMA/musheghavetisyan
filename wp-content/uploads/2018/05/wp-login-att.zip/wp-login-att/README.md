wp-login-attempt-log
====================

WordPress plugin that displays login attempts.

To install, simply place files in `[WORDPRESS_ROOT]/wp-content/plugins/wp-login-attempt-log`.

Coded by [Simon Fredsted](http://simonfredsted.com). (c) 2014

![screenshot](http://filedump.fredsted.me/Screen%20Shot%202014-06-14%20at%2023.43.25.png)
